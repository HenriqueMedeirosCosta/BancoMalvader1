package Model;

public class Endereço {

}
